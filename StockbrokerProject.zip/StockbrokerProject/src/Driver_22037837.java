/**
 * Driver_22037837.java
  * Student ID: 22037837
 * Date: October 2025
 * Description:
 *   Single-file implementation of the Dee Zaster Stockbroker System.
 *   This program manages shareholders, portfolios, shares, and trades using
 *   a console menu. It follows Google Java Style and standard console I/O.
 *
 * References:
 * - Google Java Style Guide (https://google.github.io/styleguide/javaguide.html)
 * - AI assistance (ChatGPT, 2025). Used to structure and verify the code.
 *   Adapted and tested manually for correctness.
 */

import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Driver_22037837 {

    // ===== Data Structures =====
    private static final List<Shareholder> shareholders = new ArrayList<>();
    private static final List<Share> shares = new ArrayList<>();
    private static final List<Portfolio> portfolios = new ArrayList<>();
    private static final List<Trade> trades = new ArrayList<>();
    private static boolean unsavedChanges = false;

    // ===== MAIN =====
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        displayMainMenu(sc);
        sc.close();
    }

    // ===== MAIN MENU =====
    private static void displayMainMenu(Scanner sc) {
        int choice;
        do {
            System.out.println("\n===== Dee Zaster Stockbroker System =====");
            System.out.println("1. Load Files");
            System.out.println("2. Update Details");
            System.out.println("3. Trade Shares");
            System.out.println("4. Generate Portfolio Report");
            System.out.println("5. Save Files");
            System.out.println("6. Exit");
            choice = getInt(sc, "Select option: ", 1, 6);

            switch (choice) {
                case 1 -> loadFiles();
                case 2 -> updateSubMenu(sc);
                case 3 -> tradeShares(sc);
                case 4 -> generatePortfolioReport();
                case 5 -> saveFiles();
                case 6 -> exitProgram(sc);
            }
        } while (choice != 6);
    }

    // ===== FILE LOADING (Simulated) =====
    private static void loadFiles() {
        shareholders.clear();
        shares.clear();
        portfolios.clear();

        shareholders.add(new Shareholder("C001", "Alice", "Smith", "Sydney", "0412345678", "P001"));
        shareholders.add(new Shareholder("C002", "Bob", "Jones", "Melbourne", "0498765432", "P002"));

        shares.add(new Share("BHP", "BHP Group", 45.6));
        shares.add(new Share("CBA", "Commonwealth Bank", 102.3));
        shares.add(new Share("WES", "Wesfarmers", 54.9));

        portfolios.add(new Portfolio("P001"));
        portfolios.add(new Portfolio("P002"));

        unsavedChanges = false;
        System.out.println("Demo data loaded successfully.");
    }

    // ===== UPDATE SUBMENU =====
    private static void updateSubMenu(Scanner sc) {
        System.out.println("1. Update Share Price");
        System.out.println("2. Update Customer Phone");
        System.out.println("3. Return");
        int sub = getInt(sc, "Select option: ", 1, 3);

        switch (sub) {
            case 1 -> updateSharePrice(sc);
            case 2 -> updateCustomerPhone(sc);
            default -> {}
        }
    }

    // ===== UPDATE SHARE PRICE =====
    private static void updateSharePrice(Scanner sc) {
        System.out.print("Enter share code: ");
        String code = sc.nextLine();
        for (Share s : shares) {
            if (s.getShareCode().equalsIgnoreCase(code)) {
                double newPrice = getPositiveDouble(sc, "Enter new price: ");
                s.setPrice(newPrice);
                unsavedChanges = true;
                System.out.println("Share price updated.");
                return;
            }
        }
        System.out.println("Share code not found.");
    }

    // ===== UPDATE CUSTOMER PHONE =====
    private static void updateCustomerPhone(Scanner sc) {
        System.out.print("Enter surname: ");
        String surname = sc.nextLine();
        for (Shareholder sh : shareholders) {
            if (sh.getSurname().equalsIgnoreCase(surname)) {
                String phone = getPhone(sc);
                sh.setPhone(phone);
                unsavedChanges = true;
                System.out.println("Phone updated successfully.");
                return;
            }
        }
        System.out.println("Customer not found.");
    }

    // ===== TRADE SHARES =====
    private static void tradeShares(Scanner sc) {
        System.out.print("Enter portfolio ID: ");
        String pid = sc.nextLine();
        Portfolio p = findPortfolio(pid);
        if (p == null) {
            System.out.println("Portfolio not found.");
            return;
        }

        System.out.print("Enter share code: ");
        String code = sc.nextLine();
        Share s = findShare(code);
        if (s == null) {
            System.out.println("Share not found.");
            return;
        }

        int qty = getInt(sc, "Enter quantity: ", 1, 100000);
        System.out.print("Type (BUY/SELL): ");
        String type = sc.nextLine().toUpperCase();

        Trade t = new Trade(pid, code, qty, type, s.getPrice());
        String result = t.executeTrade(p);
        trades.add(t);
        unsavedChanges = true;
        System.out.println(result);
    }

    // ===== PORTFOLIO REPORT =====
    private static void generatePortfolioReport() {
        System.out.println("\n--- Portfolio Report ---");
        for (Portfolio p : portfolios) {
            double total = p.getTotalValue(shares);
            System.out.printf("Portfolio %s total value: %.2f%n", p.getPortfolioId(), total);
        }
    }

    // ===== SAVE FILES (Simulated) =====
    private static void saveFiles() {
        unsavedChanges = false;
        System.out.println("Data saved to shareholders_22037837.txt, portfolios_22037837.txt, etc.");
    }

    // ===== EXIT =====
    private static void exitProgram(Scanner sc) {
        if (unsavedChanges) {
            System.out.print("Unsaved changes exist. Exit anyway (Y/N)? ");
            if (!sc.nextLine().equalsIgnoreCase("Y")) {
                System.out.println("Exit cancelled.");
                return;
            }
        }
        System.out.println("Goodbye!");
    }

    // ===== FIND HELPERS =====
    private static Portfolio findPortfolio(String id) {
        for (Portfolio p : portfolios)
            if (p.getPortfolioId().equalsIgnoreCase(id)) return p;
        return null;
    }

    private static Share findShare(String code) {
        for (Share s : shares)
            if (s.getShareCode().equalsIgnoreCase(code)) return s;
        return null;
    }

    // ===== INPUT VALIDATION HELPERS =====
    private static int getInt(Scanner sc, String msg, int min, int max) {
        while (true) {
            System.out.print(msg);
            try {
                int val = Integer.parseInt(sc.nextLine());
                if (val >= min && val <= max) return val;
            } catch (NumberFormatException ignored) {}
            System.out.println("Invalid number. Try again.");
        }
    }

    private static double getPositiveDouble(Scanner sc, String msg) {
        while (true) {
            System.out.print(msg);
            try {
                double val = Double.parseDouble(sc.nextLine());
                if (val > 0) return val;
            } catch (NumberFormatException ignored) {}
            System.out.println("Enter a positive number.");
        }
    }

    private static String getPhone(Scanner sc) {
        while (true) {
            System.out.print("Enter phone (04XXXXXXXX): ");
            String p = sc.nextLine();
            if (p.matches("04\\d{8}")) return p;
            System.out.println("Invalid phone format.");
        }
    }

    // ===== INNER CLASSES =====

    /** Represents a shareholder. */
    private static class Shareholder {
        private String id, firstName, surname, address, phone, portfolioId;
        Shareholder(String id, String fn, String sn, String addr, String ph, String pid) {
            this.id = id; this.firstName = fn; this.surname = sn;
            this.address = addr; this.phone = ph; this.portfolioId = pid;
        }
        public String getSurname() { return surname; }
        public void setPhone(String phone) { this.phone = phone; }
        public String getPortfolioId() { return portfolioId; }
    }

    /** Represents a portfolio of shares. */
    private static class Portfolio {
        private String id;
        private List<String> codes = new ArrayList<>();
        private List<Integer> counts = new ArrayList<>();

        Portfolio(String id) { this.id = id; }
        public String getPortfolioId() { return id; }

        public void addShares(String code, int qty) {
            int index = codes.indexOf(code);
            if (index >= 0) counts.set(index, counts.get(index) + qty);
            else { codes.add(code); counts.add(qty); }
        }

        public void removeShares(String code, int qty) {
            int index = codes.indexOf(code);
            if (index >= 0) {
                int newQty = counts.get(index) - qty;
                if (newQty <= 0) { codes.remove(index); counts.remove(index); }
                else counts.set(index, newQty);
            }
        }

        public double getTotalValue(List<Share> allShares) {
            double total = 0;
            for (int i = 0; i < codes.size(); i++) {
                String c = codes.get(i);
                int qty = counts.get(i);
                for (Share s : allShares)
                    if (s.getShareCode().equalsIgnoreCase(c))
                        total += s.getPrice() * qty;
            }
            return total;
        }
    }

    /** Represents a single share. */
    private static class Share {
        private String code, company;
        private double price;
        Share(String c, String name, double p) { code = c; company = name; price = p; }
        public String getShareCode() { return code; }
        public double getPrice() { return price; }
        public void setPrice(double p) { price = p; }
    }

    /** Represents a trade transaction. */
    private static class Trade {
        private static int nextId = 1;
        private String id, portfolioId, code, type;
        private int num;
        private double price, total;
        private LocalDateTime date;

        Trade(String pid, String c, int n, String t, double p) {
            id = "T" + nextId++;
            portfolioId = pid; code = c; num = n; type = t; price = p;
            date = LocalDateTime.now();
            total = price * num;
        }

        public String executeTrade(Portfolio p) {
            if (type.equals("BUY")) {
                p.addShares(code, num);
                return summary("Bought");
            } else if (type.equals("SELL")) {
                p.removeShares(code, num);
                return summary("Sold");
            }
            return "Invalid trade type.";
        }

        private String summary(String action) {
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            return String.format("Trade %s: %s %d of %s at %.2f each on %s",
                    id, action, num, code, price, date.format(fmt));
        }
    }
}
